package com.data.settopb;

import android.app.Notification;
import android.app.Service;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.IBinder;
import android.os.Message;
import android.util.Log;
import android.os.Handler;
import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;
import org.apache.http.client.HttpClient;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.protocol.HTTP;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;
import java.util.Vector;

public class MyService extends Service {
    boolean exitflag = false;

    public MyService() {
        Log.d("SettobB Service", "Service Start");

        try{
            new readTask().execute();
        }catch (Exception e) {
        }
    }


    SHBind.Stub mBinder = new SHBind.Stub() {
        public void exitservice() {
            exitflag = true;
        }
    };

    final Handler handler = new Handler(){
        @Override
        public void handleMessage(Message msg){
            switch (msg.what) {
                case 0:
                    break;
                case 1:
                    try{
                        new writeTask().execute();
                    }catch (Exception e) {
                    }
                    break;
                case 2:
                    try{
                        new writeTask().execute();
                    }catch (Exception e) {
                    }
                    break;
                case 3:
                    Intent intent = new Intent(MyService.this, MainActivity.class);
                    intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                    startActivity(intent);
                    try{
                        new writeTask().execute();
                    }catch (Exception e) {
                    }
                    break;
                case 4:
                    try{
                        new writeTask().execute();
                    }catch (Exception e) {
                    }
                    break;
            }
            if(exitflag == false) {
                try{
                    new readTask().execute();
                }catch (Exception e) {
                }
            }
        }
    };

    @Override
    public IBinder onBind(Intent intent) {
       return mBinder;
    }

    class readTask extends AsyncTask<Void, Void, String> {
        @Override
        protected String doInBackground(Void... voids) {
            // TODO Auto-generated method stub

            try{
                HttpPost request = new HttpPost("http://shuphin.cafe24.com/shread.php");
                //전달할 인자들
                //Vector<NameValuePair> nameValue = new Vector<NameValuePair>();
                //nameValue.add(new BasicNameValuePair("id", id));

                //웹 접속 - utf-8 방식으로
                //HttpEntity enty = new UrlEncodedFormEntity(nameValue, HTTP.UTF_8);
                //request.setEntity(enty);

                HttpClient client = new DefaultHttpClient();
                HttpResponse res = client.execute(request);
                //웹 서버에서 값받기
                HttpEntity entityResponse = res.getEntity();
                InputStream im = entityResponse.getContent();
                BufferedReader reader = new BufferedReader(new InputStreamReader(im, HTTP.UTF_8));

                String result = "";
                String tmp = "";
                //버퍼에있는거 전부 더해주기
                //readLine -> 파일내용을 줄 단위로 읽기
                while((tmp = reader.readLine())!= null)
                {
                    if(tmp != null)
                    {
                        result += tmp;
                    }
                }
                im.close();
                Log.d("Hello", result);
                result = result.trim();

                switch (result) {
                    case "0" :
                        handler.sendEmptyMessage(0);
                        break;
                    case "1" :
                        handler.sendEmptyMessage(1);
                        break;
                    case "2" :
                        handler.sendEmptyMessage(2);
                        break;
                    case "3" :
                        handler.sendEmptyMessage(3);
                        break;
                    case "4" :
                        handler.sendEmptyMessage(4);
                        break;
                }

                return result;
            }catch(UnsupportedEncodingException e){
                e.printStackTrace();
            }catch(IOException e){
                e.printStackTrace();
            }
            //오류시 null 반환
            return null;
        }
        //asyonTask 3번째 인자와 일치 매개변수값 -> doInBackground 리턴값이 전달됨
        //AsynoTask 는 preExcute - doInBackground - postExecute 순으로 자동으로 실행됩니다.
        //ui는 여기서 변경
        protected void onPostExecute(String value){
            super.onPostExecute(value);
        }
    }

    class writeTask extends AsyncTask<Void, Void, String> {
        @Override
        protected String doInBackground(Void... voids) {
            // TODO Auto-generated method stub
            try{
                HttpPost request = new HttpPost("http://shuphin.cafe24.com/shwrite.php");
                //전달할 인자들
                Vector<NameValuePair> nameValue = new Vector<NameValuePair>();
                nameValue.add(new BasicNameValuePair("signal", "0"));

                //웹 접속 - utf-8 방식으로
                HttpEntity enty = new UrlEncodedFormEntity(nameValue, HTTP.UTF_8);
                request.setEntity(enty);

                HttpClient client = new DefaultHttpClient();
                HttpResponse res = client.execute(request);
                //웹 서버에서 값받기
                HttpEntity entityResponse = res.getEntity();
                InputStream im = entityResponse.getContent();
                BufferedReader reader = new BufferedReader(new InputStreamReader(im, HTTP.UTF_8));

                String result = "";
                String tmp = "";
                //버퍼에있는거 전부 더해주기
                //readLine -> 파일내용을 줄 단위로 읽기
                while((tmp = reader.readLine())!= null)
                {
                    if(tmp != null)
                    {
                        result += tmp;
                    }
                }
                im.close();
                Log.d("Hello", result);
                result = result.trim();
                return result;
            }catch(UnsupportedEncodingException e){
                e.printStackTrace();
            }catch(IOException e){
                e.printStackTrace();
            }
            //오류시 null 반환
            return null;
        }
        //asyonTask 3번째 인자와 일치 매개변수값 -> doInBackground 리턴값이 전달됨
        //AsynoTask 는 preExcute - doInBackground - postExecute 순으로 자동으로 실행됩니다.
        //ui는 여기서 변경
        protected void onPostExecute(String value){
            super.onPostExecute(value);
        }
    }
}
