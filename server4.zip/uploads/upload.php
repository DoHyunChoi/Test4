<script>
		String.prototype.popupView = function () {

		var img_view = this;
		var x = x + 20 ;
		var y = y + 30 ;
		htmlz = "<html><head><title>이미지크게보기</title><style>body{margin:0;cursor:hand;}</style></head><body scroll=auto onload='width1=document.all.Timage.width;if(width1>1024)width1=1024;height1=document.all.Timage.height;if(height1>768)height1=768;top.window.resizeTo(width1+30,height1+54);' onclick='top.window.close();'><img src='"+img_view+"' title='클릭하시면 닫힙니다.' name='Timage' id='Timage'></body></html>"
		imagez = window.open('', "image", "width="+ 100 +", height="+ 100 +", top=0,left=0,scrollbars=auto,resizable=1,toolbar=0,menubar=0,location=0,directories=0,status=1");
		imagez.document.open();
		imagez.document.write(htmlz)
		imagez.document.close();
		}

</script>

<?
$ext = array('.gif','.jpg','.png'); // 이미지 확장자 지정 
$path = './'; // 뒤에 경로 구분자 붙여주기 

if ( $dh = opendir($path) ) { 
    while ( ($read=readdir($dh))!==false ) 
    { 
        if ( !is_file($path.$read) || !in_array(strrchr($read,'.'),$ext) ) continue; 

		
		
		echo "<td style='padding:10px;'><img src='$read' style='width:33.3%; heigth:33.3%;' onclick='this.src.popupView()'></td>";
    } 
    closedir($dh); 
}
?> 