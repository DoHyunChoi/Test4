<? 
include "d.php";

// 변수 내용 확인
$signal = "asdf"; 

$mysql = "UPDATE $board SET signal='$signal'";
$result = mysql_query($mysql);

//글정보 가져오기
$query = "SELECT * FROM $board WHERE signal";
$result=mysql_query($query, $conn);
$row=mysql_fetch_array($result);

// 변수 내용 출력


mysql_close($conn);

echo "$row[signal]";
?>

