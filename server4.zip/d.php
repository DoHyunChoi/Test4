<?
	$board="lesson";
	$conn=mysql_connect("localhost", "shuphin", "shuphin1");
	mysql_select_db("shuphin",$conn);
	mysql_query('set names euckr');
?>