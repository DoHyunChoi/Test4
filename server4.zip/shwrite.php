<? 
include "d.php";

$signal = $_POST['signal'];

$mysql = "UPDATE $board SET signal='$signal'";
$result = mysql_query($mysql);

mysql_close($conn);

echo $row['signal'];
?>

