<? 
	include "d.php";

	$tvoff = $_POST['tvoff'];

	mysql_query("set session character_set_connection=utf8;");

	mysql_query("set session character_set_results=utf8;");

	mysql_query("set session character_set_client=utf8;");

	$mysql = "UPDATE $board SET tvoff ='$tvoff'";
	$result = mysql_query($mysql);

	mysql_close($conn);

	echo "$row[tvoff]";
?>

