  <meta http-equiv="Content-Type" content="text/html; charset=utf-8">

<form action=login_post.php method=post>
<table width=300 border=1>
<tr>
<td width=50>
ID : <td><input type=text name=user_id size=19 maxlength=20>
</tr>
<tr>
<td>
PASS : <td><input type=password name=pw size=20 maxlength=20>
</tr>
<tr><td colspan=2 align=center> 
<input type=submit value=로그인>
</tr>
</form>