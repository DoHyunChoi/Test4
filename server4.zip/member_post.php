  <meta http-equiv="Content-Type" content="text/html; charset=utf-8">

<?php
 
 $id = $_POST['id'];
 $pw = $_POST['pw'];
 $name = $_POST['name'];
 $email = $_POST['email'];
 $memo = $_POST['memo'];
 
 $connect = mysql_connect("localhost","shuphin","shuphin1");
 mysql_query("set names euckr");
 mysql_select_db("shuphin");
 
 $query = "insert into mem(name,id,pw,email,memo)
    values('$name', '$id','$pw','$email','$memo')";
 mysql_query($query, $connect);
 mysql_close($connect);

?>
<script>
location.href='login_test.php';
</script>