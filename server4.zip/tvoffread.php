<? 
include "d.php";

//글정보 가져오기
$query = "SELECT * FROM $board";
$result=mysql_query($query, $conn);
$row=mysql_fetch_array($result);

echo $row['tvoff'];


// 변수 내용 출력
mysql_close($conn);


?>

